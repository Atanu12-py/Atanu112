package com.User.UserMgmntSys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserMgmntSysApplicationTests {

	@Test
	void contextLoads() {
	}

}
